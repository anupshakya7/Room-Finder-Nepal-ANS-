package com.example.roomfindernepalasn;

public class Customer {

    public String FullName,UserName,Email,Gender;

    public Customer(){

    }

    public Customer(String fullname,String username,String email,String gender){
        FullName=fullname;
        UserName=username;
        Email=email;
        Gender=gender;
    }

}
